import { Component } from "react";

import React from "react";
//import { useState } from "react";
//import axios from "axios";
import Search from "./pages/searchbutton";

//const CLIENT_ID = process.env.CLIENT_ID

//const CLIENT_SECRET = process.env.CLIENT_SECRET

class App extends Component {
  state = {access_token:"", searchResult:[], searchQuery:"" };


  handleAccessToken = () => {
    window.location.href = "https://accounts.spotify.com/authorize?client_id=0351cc6087e444268ec2ff1e557de0c6&scopes=playlist-modify-private&response_type=token&redirect_uri=http://localhost:3000"
  }

  handleSearch = async() => {
 
    await fetch(
        `https://api.spotify.com/v1/search?q=${this.state.searchQuery.replaceAll(" ","+" )}&type=album&limit=12`,{
            method: "GET",
            headers: {
                Authorization: `Bearer ${this.state.access_token}`
            }
        }
        
        )
            .then((res) => res.json())
            .then((res) => this.setState({searchResult: res.albums.items}));
  }

  componentDidMount() {
    const token =
      window.location.hash &&
      window.location.hash
        .substring(1)
        .split("&")
        .find((elem) => elem.startsWith("access_token"))
        .replace("access_token=", "");
    if (token) {
      this.setState({ access_token: token });
    }
  }

  render() {
    // console.log(this.state.searchResult)
      
    return(
      <div className="App">
        {
          this.state.access_token === "" ? <button onClick={this.handleAccessToken}>Login to Spotify</button> : <Search 
          handleSearch={this.handleSearch} 
          toggleFunction={(value) => this.setState({searchQuery:value})} />

          
        }
        {
          this.state.searchResult.map((item) =>{
            return(
              <div key={item.id}>
                <img src={item.images[1].url} alt="foto" />
                <p>artist={item.artists[0].name}</p>
                <p>date={item.release_date}</p>
                <p>title={item.name}</p>
              </div>
            )
          })
        }
      </div>
    )
  };
}

export default App;




























/*
const CLIENT_ID = process.env.CLIENT_ID

const CLIENT_SECRET = process.env.CLIENT_SECRET

const Home = () => {
  const connectUser = () => {
    console.log("Hello")
    axios.get(`https://accounts.spotify.com/authorize?client_id=${CLIENT_ID}&redirect_uri=https://localhost:3000/callback/&response_type=token&scopes=playlist-modify-private`)
            .then(response => {
        console.log(response)

    })
    .catch (err => {
        console.log(err)
    })
  }

  return(
    <div>
      {console.log(CLIENT_ID)}
      {console.log(CLIENT_SECRET)}
      <button onClick = {connectUser}>Push</button>
    </div>
  )
}
*/
//export {Home};